#ifndef CARPARTS_H
#define CARPARTS_H

void Wing(unsigned int carbon_fiber, unsigned int nose_top, unsigned int red);
void Monocoque_Front(unsigned int carbon_fiber, unsigned int mono_side,  unsigned int red);
void Halo(unsigned int carbon_fiber);
void RearWing(unsigned int carbon_fiber);
#endif