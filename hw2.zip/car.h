#ifndef CAR_H
#define CAR_H

struct Vec2 { float x, y; };
struct Vec3 { float x, y, z; };

void car();
#endif