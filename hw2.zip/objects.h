#ifndef OBJECTS_H
#define OBJECTS_H

void Plane(int, double, double, double,
double, double, double,double,
double, double, double, double);

void cube(double ,double ,double ,
    double ,double ,double ,double );

void LightPoles(double , double , double );

void GridPosMarkers(double , double );

void GrandStand(double , double , double );

void StartLights(double , double );

#endif