#ifndef CARPARTS_H
#define CARPARTS_H

void Wing();
void Monocoque_Front();
#endif